<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    try {
        $stmt->execute([$username, $password]);
        echo "Kayıt başarılı! <a href='index.html'>Giriş yap</a>";
    } catch (PDOException $e) {
        echo "Kayıt başarısız: " . $e->getMessage();
    }
}
?>