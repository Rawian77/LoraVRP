<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: index.html");
    exit;
}
echo "Hoş geldin, " . $_SESSION["user"] . " | <a href='logout.php'>Çıkış yap</a>";
?>